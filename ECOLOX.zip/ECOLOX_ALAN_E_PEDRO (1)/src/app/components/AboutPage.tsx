import { motion } from "motion/react";
import {
  ArrowLeft,
  Leaf,
  Users,
  Target,
  Award,
} from "lucide-react";
import imgSpiderLogo from "figma:asset/125f7b92600938ab83c27060de9e7545337f21b8.png";

type AboutPageProps = {
  onBack: () => void;
};

export function AboutPage({ onBack }: AboutPageProps) {
  return (
    <div className="min-h-screen w-full p-6 md:p-8 max-w-5xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="mb-8 flex items-center gap-4"
      >
        <button
          onClick={onBack}
          className="p-2 rounded-xl backdrop-blur-md bg-white/10 hover:bg-white/20 border border-white/20 text-white transition-all"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-3xl text-white">
            Sobre o EcoLox
          </h1>
          <p className="text-white/70 text-sm mt-1">
            Conheça o Ecolox
          </p>
        </div>
      </motion.div>

      {/* Logo and Title Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="backdrop-blur-md bg-white/10 border border-white/20 rounded-2xl p-8 mb-6"
      >
        <div className="flex flex-col items-center text-center">
          <div className="relative w-32 h-32 rounded-full overflow-hidden opacity-90 mb-6">
            <img
              alt="EcoLox Logo"
              className="absolute inset-0 w-full h-full object-cover"
              src={imgSpiderLogo}
            />
            <div className="absolute inset-0 rounded-full shadow-[inset_0px_3.691px_64.601px_4px_rgba(0,0,0,0.25)]" />
          </div>
          <h2 className="text-4xl text-white mb-4 tracking-[12px] font-['Playfair_Display']">
            ECOLOX
          </h2>
          <p className="text-white/80 text-lg max-w-2xl">
            Um Software para pesquisadores da Aranha Marrom (Loxosceles Laeta).
          </p>
        </div>
      </motion.div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Mission Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="backdrop-blur-md bg-white/10 border border-white/20 rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-400/30">
              <Target className="w-6 h-6 text-emerald-300" />
            </div>
            <h3 className="text-xl text-white">Objetivo</h3>
          </div>
          <p className="text-white/70">
            Facilitar a coleta, organização e análise de dados
            de Amostras de coletas em campo, tornando o processo de
            pesquisa mais eficiente e acessível.
          </p>
        </motion.div>

        {/* Purpose Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="backdrop-blur-md bg-white/10 border border-white/20 rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-blue-500/20 border border-blue-400/30">
              <Leaf className="w-6 h-6 text-blue-300" />
            </div>
            <h3 className="text-xl text-white">Parceria</h3>
          </div>
          <p className="text-white/70">
            Desenvolvido em parceria com o projeto de pesquisa, do IFC - Campus Ibirama, CONDIÇÕES MICROAMBIENTAIS DA ARANHA-MARROM LOXOSCELES LAETA (NICOLET, 1849) EM EDIFICAÇÕES NÃO RESIDENCIAIS DA ZONA RURAL DE IBIRAMA (SC).
          </p>
        </motion.div>

        {/* Team Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="backdrop-blur-md bg-white/10 border border-white/20 rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-purple-500/20 border border-purple-400/30">
              <Users className="w-6 h-6 text-purple-300" />
            </div>
            <h3 className="text-xl text-white">Para Quem</h3>
          </div>
          <p className="text-white/70">
            Desenvolvido especialmente para membros do projeto do Instituto Federal Catarinense (IFC) - Campus Ibirama, mas também é útil para qualquer pesquisador ou entusiasta da Aranha Marrom.
            e pesquisadores do centro de Pesquisa e Produção de Imunobiológicos (CPPI).
            
          </p>
        </motion.div>

        {/* Quality Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="backdrop-blur-md bg-white/10 border border-white/20 rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-amber-500/20 border border-amber-400/30">
              <Award className="w-6 h-6 text-amber-300" />
            </div>
            <h3 className="text-xl text-white">Comportamento do Sistema</h3>
          </div>
          <p className="text-white/70">
            Interface intuitiva com responsividade para dispositivos móveis como celulares e tablets garantindo uma
             experiência de usuário fluida e eficiente. Além de sua versão desktop.
          </p>
        </motion.div>
      </div>

      {/* Features List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="backdrop-blur-md bg-white/10 border border-white/20 rounded-2xl p-6"
      >
        <h3 className="text-xl text-white mb-4">
          Principais Funcionalidades
        </h3>
        <ul className="space-y-3 text-white/70">
          <li className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-400 mt-2 flex-shrink-0" />
            <span>
              Registro de variáveis abióticas, como:
              temperatura, umidade, vento, luminosidade, tipo
              de solo.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-400 mt-2 flex-shrink-0" />
            <span>
              Documentação de variáveis bióticas como: predadores,
              presas, outras espécies.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-400 mt-2 flex-shrink-0" />
            <span>
              Dashboards para uma visualização rápida dos dados coletados.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-400 mt-2 flex-shrink-0" />
            <span>
              Dados salvos em nuvem, garantindo segurança e acessibilidade de qualquer lugar.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-400 mt-2 flex-shrink-0" />
            <span>
              Mapa para visualização geográfica das amostras coletadas, permitindo uma visão espacial dos dados.
            </span>
          </li>
        </ul>
      </motion.div>
    </div>
  );
}
// Wizard de cadastro e edição: coleta dados por etapas, valida o conjunto final e salva sob comando do usuário.
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft,
  ArrowRight,
  Save,
  CheckCircle,
  MapPin,
  ClipboardList,
  ThermometerSun,
  Home,
  Bug,
  ListChecks,
} from "lucide-react";
import { Button } from "@/app/components/Button";
import { LeafletMap } from "@/app/components/LeafletMap";
import { toast } from "sonner";
import type { Sample } from "@/app/App";

type NewSamplePageProps = {
  onSave: (sample: Sample) => Promise<void>;
  initialSample?: Sample | null;
  onCancel: () => void;
};

const steps = [
  { id: 0, title: "Proprietário", icon: MapPin },
  { id: 1, title: "Identificação", icon: ClipboardList },
  { id: 2, title: "Ambientais", icon: ThermometerSun },
  { id: 3, title: "Construção", icon: Home },
  { id: 4, title: "Bióticas", icon: Bug },
  { id: 5, title: "Resumo", icon: ListChecks },
];

function CardSelect({
  options,
  value,
  onChange,
  multi = false
}: {
  options: string[],
  value: string | string[],
  onChange: (v: any) => void,
  multi?: boolean
}) {
  // Controle reutilizável para opções simples e listas de seleção múltipla.
  return (
    <div className="flex flex-wrap gap-2">
      {options.map(opt => {
        const isSelected = multi ? (value as string[]).includes(opt) : value === opt;
        return (
          <button
            key={opt}
            type="button"
            onClick={() => {
              if (multi) {
                const arr = value as string[];
                onChange(arr.includes(opt) ? arr.filter(i => i !== opt) : [...arr, opt]);
              } else {
                onChange(opt);
              }
            }}
            className={`px-4 py-3 rounded-xl transition-all border ${isSelected
                ? "bg-emerald-500/30 text-emerald-100 border-emerald-400/50 shadow-[0_0_10px_rgba(52,211,153,0.2)]"
                : "bg-white/5 text-white/70 border-white/10 hover:bg-white/10"
              }`}
          >
            {opt}
          </button>
        )
      })}
    </div>
  );
}

export function NewSamplePage({
  onSave,
  initialSample,
  onCancel,
}: NewSamplePageProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isCapturingGPS, setIsCapturingGPS] = useState(false);
  const [formData, setFormData] = useState<Partial<Sample>>(() => ({
    date: new Date().toLocaleDateString("pt-BR"),
    time: new Date().toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' }),
    researcher: "",
    incomingSpiders: 0,
    outgoingSpiders: 0,
    balanceSpiders: 0,

    ownerName: "",
    ownerPhone: "",
    ownerAddress: "",
    ownerCity: "",
    ownerNeighborhood: "",
    ownerReference: "",
    latitude: -24.5833, // Default Iporanga
    longitude: -48.5833,

    sunlight: "",
    temperature: "",
    humidity: "",
    vegetation: "",
    soilType: "",
    climate: "",
    season: "",
    month: "",

    shedAge: "",
    frequencyOfUse: "",
    architecturalDetails: [],
    roofMaterial: "",
    wallMaterial: "",
    luminosity: "",
    floorMaterial: "",
    airyEnvironment: "",
    substrateMaterial: [],
    closedAreaSize: "",
    height: "",
    constructionObservations: "",

    farmAnimals: "",
    farmAnimalType: "",
    otherSpidersPresence: "",
    otherSpidersType: "",
    preyPresence: [],
    predatorPresence: [],
    biologicalObservations: "",

    ...initialSample,
  }));

  const updateField = (field: keyof Sample, value: any) => {
    // Atualizar entrada/saída recalcula o saldo imediatamente mostrado no resumo.
    setFormData(prev => {
      const next = { ...prev, [field]: value };
      if (field === 'incomingSpiders' || field === 'outgoingSpiders') {
        next.balanceSpiders = (Number(next.incomingSpiders) || 0) - (Number(next.outgoingSpiders) || 0);
      }
      return next;
    });
  };

  const captureGPS = () => {
    if (!window.isSecureContext) {
      toast.error("O GPS só funciona em uma conexão segura (HTTPS ou localhost).");
      return;
    }

    if (!navigator.geolocation) {
      toast.error("Este navegador não oferece suporte à localização.");
      return;
    }

    setIsCapturingGPS(true);
    toast.info("Obtendo localização...");

    navigator.geolocation.getCurrentPosition(
      (position) => {
        updateField('latitude', position.coords.latitude);
        updateField('longitude', position.coords.longitude);
        setIsCapturingGPS(false);
        toast.success("Localização capturada!");
      },
      (error) => {
        setIsCapturingGPS(false);
        const messages: Record<number, string> = {
          1: "Permissão de localização negada. Autorize o acesso ao GPS no navegador.",
          2: "Não foi possível determinar sua localização.",
          3: "A localização demorou para responder. Tente novamente.",
        };
        toast.error(messages[error.code] || "Não foi possível capturar a localização.");
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      },
    );
  };

  const hasValue = (value: unknown) => {
    if (Array.isArray(value)) return value.length > 0;
    if (typeof value === "number") return Number.isFinite(value);
    return typeof value === "string" ? value.trim().length > 0 : Boolean(value);
  };

  const getMissingFields = (step: number) => {
    // A lista centralizada permite navegar livremente, mas bloqueia o salvamento incompleto.
    const requiredFields: Record<number, Array<[keyof Sample, string]>> = {
      0: [
        ['ownerName', 'Nome completo'],
        ['ownerPhone', 'Telefone'],
        ['ownerAddress', 'Endereço completo'],
        ['ownerCity', 'Cidade'],
        ['ownerNeighborhood', 'Bairro'],
        ['ownerReference', 'Ponto de referência'],
        ['latitude', 'Latitude'],
        ['longitude', 'Longitude'],
      ],
      1: [
        ['date', 'Data'],
        ['time', 'Hora'],
        ['researcher', 'Pesquisador responsável'],
        ['incomingSpiders', 'Entrada de aranhas'],
        ['outgoingSpiders', 'Saída de aranhas'],
      ],
      2: [
        ['sunlight', 'Insolação'],
        ['temperature', 'Temperatura'],
        ['humidity', 'Umidade'],
        ['vegetation', 'Vegetação'],
        ['soilType', 'Tipo de solo'],
        ['climate', 'Clima'],
        ['season', 'Estação'],
        ['month', 'Mês'],
      ],
      3: [
        ['shedAge', 'Idade do galpão'],
        ['frequencyOfUse', 'Frequência de uso'],
        ['architecturalDetails', 'Detalhes arquitetônicos'],
        ['roofMaterial', 'Material do teto'],
        ['wallMaterial', 'Material da parede'],
        ['floorMaterial', 'Material do chão'],
        ['substrateMaterial', 'Material do substrato'],
        ['airyEnvironment', 'Ambiente arejado'],
        ['luminosity', 'Luminosidade'],
        ['closedAreaSize', 'Área fechada'],
        ['height', 'Altura'],
      ],
      4: [
        ['farmAnimals', 'Animais de criação'],
        ['otherSpidersPresence', 'Outras aranhas'],
        ['preyPresence', 'Presença de presas'],
        ['predatorPresence', 'Presença de predadores'],
      ],
    };

    const missing = (requiredFields[step] || [])
      .filter(([field]) => !hasValue(formData[field]))
      .map(([, label]) => label);

    if (step === 4 && formData.farmAnimals === 'Sim' && !hasValue(formData.farmAnimalType)) {
      missing.push('Tipo de animal');
    }
    if (step === 4 && formData.otherSpidersPresence === 'Sim' && !hasValue(formData.otherSpidersType)) {
      missing.push('Quais outras aranhas');
    }

    return missing;
  };

  const validateStep = (step: number) => {
    const missing = getMissingFields(step);
    if (missing.length > 0) {
      toast.error(`Preencha: ${missing.join(', ')}`);
      return false;
    }
    return true;
  };

  const nextStep = () => {
    // Avançar não valida: o usuário pode revisar qualquer etapa antes de finalizar.
    setCurrentStep(prev => Math.min(steps.length - 1, prev + 1));
  };
  const prevStep = () => setCurrentStep(prev => Math.max(0, prev - 1));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentStep !== steps.length - 1) {
      nextStep();
    }
  };

  const handleSave = async () => {
    // A validação completa ocorre somente aqui, no comando explícito de salvar.
    const firstInvalidStep = [0, 1, 2, 3, 4].find(step => getMissingFields(step).length > 0);
    if (firstInvalidStep !== undefined) {
      setCurrentStep(firstInvalidStep);
      validateStep(firstInvalidStep);
      return;
    }

    const finalSample = {
      ...formData,
      id: formData.id || Date.now().toString().slice(-6),
    } as Sample;

    setIsSaving(true);
    try {
      await onSave(finalSample);
      setShowSuccess(true);
    } catch {
      setShowSuccess(false);
    } finally {
      setIsSaving(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-medium text-white mb-4">Dados do Proprietário</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white/70 text-sm mb-1">Nome Completo</label>
                <input type="text" value={formData.ownerName} onChange={e => updateField('ownerName', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Telefone</label>
                <input type="text" value={formData.ownerPhone} onChange={e => updateField('ownerPhone', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-white/70 text-sm mb-1">Endereço Completo</label>
                <input type="text" value={formData.ownerAddress} onChange={e => updateField('ownerAddress', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Cidade</label>
                <input type="text" value={formData.ownerCity} onChange={e => updateField('ownerCity', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Bairro</label>
                <input type="text" value={formData.ownerNeighborhood} onChange={e => updateField('ownerNeighborhood', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-white/70 text-sm mb-1">Ponto de Referência</label>
                <input type="text" value={formData.ownerReference} onChange={e => updateField('ownerReference', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
            </div>

            <div className="mt-6 border-t border-white/10 pt-6">
              <div className="flex justify-between items-center mb-4">
                <label className="block text-white/70 text-sm">Localização GPS (Mova o marcador)</label>
                <Button type="button" variant="secondary" disabled={isCapturingGPS} onClick={captureGPS}>
                  {isCapturingGPS ? "Capturando..." : "Capturar GPS"}
                </Button>
              </div>
              <LeafletMap
                mode="picker"
                defaultLat={formData.latitude}
                defaultLng={formData.longitude}
                onLocationSelect={(lat, lng) => {
                  updateField('latitude', lat);
                  updateField('longitude', lng);
                }}
              />
              <p className="text-xs text-white/50 mt-2">Lat: {formData.latitude?.toFixed(5)} / Lng: {formData.longitude?.toFixed(5)}</p>
            </div>
          </div>
        );
      case 1:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-medium text-white mb-4">Identificação da Coleta</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white/70 text-sm mb-1">Data</label>
                <input type="text" value={formData.date} onChange={e => updateField('date', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Hora</label>
                <input type="time" value={formData.time} onChange={e => updateField('time', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-white/70 text-sm mb-1">Pesquisador Responsável</label>
                <input type="text" value={formData.researcher} onChange={e => updateField('researcher', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Entrada de Aranhas</label>
                <input type="number" min="0" value={formData.incomingSpiders} onChange={e => updateField('incomingSpiders', parseInt(e.target.value) || 0)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-1">Saída de Aranhas</label>
                <input type="number" min="0" value={formData.outgoingSpiders} onChange={e => updateField('outgoingSpiders', parseInt(e.target.value) || 0)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </div>
              <div className="md:col-span-2 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
                <p className="text-emerald-200 text-sm">Saldo de Aranhas</p>
                <p className="text-3xl font-bold text-emerald-400">{formData.balanceSpiders}</p>
              </div>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-medium text-white mb-4">Variáveis Ambientais</h2>

            <div><label className="block text-white/70 text-sm mb-2">Insolação</label>
              <CardSelect options={['Baixa', 'Média', 'Alta']} value={formData.sunlight || ''} onChange={v => updateField('sunlight', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Temperatura</label>
              <CardSelect options={['Baixa', 'Média', 'Intensa']} value={formData.temperature || ''} onChange={v => updateField('temperature', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Umidade</label>
              <CardSelect options={['Baixa', 'Média', 'Intensa']} value={formData.humidity || ''} onChange={v => updateField('humidity', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Vegetação</label>
              <CardSelect options={['Pouca', 'Mediana', 'Abundante']} value={formData.vegetation || ''} onChange={v => updateField('vegetation', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Tipo de Solo</label>
              <CardSelect options={['Seco', 'Arenoso', 'Barro Vermelho', 'Argiloso', 'Calcário']} value={formData.soilType || ''} onChange={v => updateField('soilType', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Clima</label>
              <CardSelect options={['Ensolarado', 'Sol com nuvens', 'Nublado', 'Nevoeiro', 'Chuva', 'Tempestade']} value={formData.climate || ''} onChange={v => updateField('climate', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Estação</label>
              <CardSelect options={['Verão', 'Outono', 'Inverno', 'Primavera']} value={formData.season || ''} onChange={v => updateField('season', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Mês</label>
              <select value={formData.month} onChange={e => updateField('month', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none">
                <option value="" className="text-black">Selecione...</option>
                {['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'].map(m => (
                  <option key={m} value={m} className="text-black">{m}</option>
                ))}
              </select></div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-medium text-white mb-4">Características da Construção</h2>

            <div><label className="block text-white/70 text-sm mb-2">Idade do Galpão</label>
              <CardSelect options={['1 a 5 anos', '5 a 10 anos', '10 a 20 anos', '20 a 30 anos', 'Mais de 30 anos']} value={formData.shedAge || ''} onChange={v => updateField('shedAge', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Frequência de Uso</label>
              <CardSelect options={['Mensal', 'Semanal', 'Diária']} value={formData.frequencyOfUse || ''} onChange={v => updateField('frequencyOfUse', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Detalhes Arquitetônicos (Múltiplo)</label>
              <CardSelect multi options={['Porão', 'Sótão', 'Frestas', 'Espaço aberto']} value={formData.architecturalDetails || []} onChange={v => updateField('architecturalDetails', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Material do Teto</label>
              <CardSelect options={['Metal', 'Telha', 'Laje', 'Eternit']} value={formData.roofMaterial || ''} onChange={v => updateField('roofMaterial', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Material da Parede</label>
              <CardSelect options={['Madeira', 'Concreto', 'Metal', 'Tijolo']} value={formData.wallMaterial || ''} onChange={v => updateField('wallMaterial', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Material do Chão</label>
              <CardSelect options={['Piso', 'Madeira', 'Concreto', 'Tijolo', 'Grama', 'Solo']} value={formData.floorMaterial || ''} onChange={v => updateField('floorMaterial', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Material do Substrato (Múltiplo)</label>
              <CardSelect multi options={['Palha', 'Madeira', 'Papelão', 'Plástico', 'Grãos', 'Metais', 'Sacos de ração', 'Serragem']} value={formData.substrateMaterial || []} onChange={v => updateField('substrateMaterial', v)} /></div>

            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-white/70 text-sm mb-2">Ambiente Arejado</label>
                <CardSelect options={['Sim', 'Não']} value={formData.airyEnvironment || ''} onChange={v => updateField('airyEnvironment', v)} /></div>

              <div><label className="block text-white/70 text-sm mb-2">Luminosidade</label>
                <CardSelect options={['Sem iluminação', 'Baixa', 'Alta', 'Luz natural']} value={formData.luminosity || ''} onChange={v => updateField('luminosity', v)} /></div>

              <div><label className="block text-white/70 text-sm mb-2">Área Fechada</label>
                <CardSelect options={['Pequena', 'Média', 'Grande']} value={formData.closedAreaSize || ''} onChange={v => updateField('closedAreaSize', v)} /></div>

              <div><label className="block text-white/70 text-sm mb-2">Altura</label>
                <CardSelect options={['Até 2m', 'Até 2,5m', 'Até 3m', 'Até 3,5m']} value={formData.height || ''} onChange={v => updateField('height', v)} /></div>
            </div>

            <div>
              <label className="block text-white/70 text-sm mb-1">Observações da Construção</label>
              <textarea rows={3} value={formData.constructionObservations} onChange={e => updateField('constructionObservations', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-medium text-white mb-4">Variáveis Bióticas</h2>

            <div><label className="block text-white/70 text-sm mb-2">Animais de Criação</label>
              <CardSelect options={['Sim', 'Não']} value={formData.farmAnimals || ''} onChange={v => updateField('farmAnimals', v)} /></div>

            {formData.farmAnimals === 'Sim' && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                <label className="block text-white/70 text-sm mb-1">Tipo de Animal</label>
                <input type="text" value={formData.farmAnimalType} onChange={e => updateField('farmAnimalType', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </motion.div>
            )}

            <div><label className="block text-white/70 text-sm mb-2">Outras Aranhas</label>
              <CardSelect options={['Sim', 'Não']} value={formData.otherSpidersPresence || ''} onChange={v => updateField('otherSpidersPresence', v)} /></div>

            {formData.otherSpidersPresence === 'Sim' && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                <label className="block text-white/70 text-sm mb-1">Quais outras aranhas?</label>
                <input type="text" value={formData.otherSpidersType} onChange={e => updateField('otherSpidersType', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
              </motion.div>
            )}

            <div><label className="block text-white/70 text-sm mb-2">Presença de Presas (Múltiplo)</label>
              <CardSelect multi options={['Baratas', 'Grilos', 'Moscas', 'Mariposas', 'Outros insetos']} value={formData.preyPresence || []} onChange={v => updateField('preyPresence', v)} /></div>

            <div><label className="block text-white/70 text-sm mb-2">Presença de Predadores (Múltiplo)</label>
              <CardSelect multi options={['Anfíbios', 'Répteis', 'Aves', 'Roedores', 'Insetos']} value={formData.predatorPresence || []} onChange={v => updateField('predatorPresence', v)} /></div>

            <div>
              <label className="block text-white/70 text-sm mb-1">Observações Biológicas</label>
              <textarea rows={3} value={formData.biologicalObservations} onChange={e => updateField('biologicalObservations', e.target.value)} className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:ring-2 focus:ring-emerald-500 outline-none" />
            </div>
          </div>
        );
      case 5:
        return (
          <div className="space-y-6">
            <h2 className="text-xl font-medium text-white mb-4">Resumo da Coleta</h2>

            <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-sm text-white/80 space-y-4 max-h-[60vh] overflow-y-auto pr-2">
              <div>
                <h3 className="font-semibold text-emerald-400 mb-1 border-b border-white/10 pb-1">Identificação</h3>
                <p>Proprietário: {formData.ownerName || 'Não preenchido'}</p>
                <p>Data: {formData.date} - {formData.time}</p>
                <p>Local: {formData.ownerCity} / {formData.ownerNeighborhood}</p>
                <p>Saldo Aranhas: <span className="font-bold text-white">{formData.balanceSpiders}</span></p>
              </div>

              <div>
                <h3 className="font-semibold text-emerald-400 mb-1 border-b border-white/10 pb-1">Ambientais</h3>
                <p>Temp: {formData.temperature} | Umid: {formData.humidity} | Insolação: {formData.sunlight}</p>
                <p>Solo: {formData.soilType} | Clima: {formData.climate}</p>
              </div>

              <div>
                <h3 className="font-semibold text-emerald-400 mb-1 border-b border-white/10 pb-1">Construção & Bióticas</h3>
                <p>Idade: {formData.shedAge}</p>
                <p>Detalhes: {formData.architecturalDetails?.join(', ')}</p>
                <p>Presas: {formData.preyPresence?.join(', ')}</p>
                <p>Predadores: {formData.predatorPresence?.join(', ')}</p>
                <p>Animais de criação: {formData.farmAnimals}</p>
                {formData.farmAnimals === 'Sim' && formData.farmAnimalType && (
                  <p>Tipo de animal: {formData.farmAnimalType}</p>
                )}
                {formData.otherSpidersPresence === 'Sim' && formData.otherSpidersType && (
                  <p>Quais outras aranhas: {formData.otherSpidersType}</p>
                )}
                {formData.constructionObservations && (
                  <p>Observações da construção: {formData.constructionObservations}</p>
                )}
                {formData.biologicalObservations && (
                  <p>Observações biológicas: {formData.biologicalObservations}</p>
                )}
              </div>
            </div>

            <div className="flex gap-2">
              <Button type="button" variant="secondary" className="flex-1 text-center" onClick={() => setCurrentStep(0)}>Editar Dados</Button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <motion.div
      className="min-h-screen w-full flex flex-col max-w-2xl mx-auto md:py-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <div className="bg-black/40 backdrop-blur-xl md:rounded-3xl border-white/10 md:border md:shadow-2xl flex-1 flex flex-col">
        {/* Header */}
        <div className="p-4 md:p-6 border-b border-white/10 flex items-center gap-4">
          <button onClick={onCancel} className="p-2 rounded-full hover:bg-white/10 text-white transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl font-semibold text-white">
              {initialSample ? "Editar Coleta" : "Nova Coleta"}
            </h1>

            <p className="text-emerald-400 text-xs">Etapa {currentStep + 1} de {steps.length}</p>
          </div>
        </div>

        {/* Stepper Progress */}
        <div className="px-6 pt-6">
          <div className="flex justify-between relative">
            <div className="absolute top-1/2 left-0 right-0 h-[2px] bg-white/10 -z-10 -translate-y-1/2" />
            <div className="absolute top-1/2 left-0 h-[2px] bg-emerald-500 -z-10 -translate-y-1/2 transition-all duration-300" style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }} />

            {steps.map((step, i) => {
              const Icon = step.icon;
              const isActive = i === currentStep;
              const isPassed = i < currentStep;
              return (
                <div key={step.id} className="flex flex-col items-center gap-2">
                  <button
                    type="button"
                    disabled={i === steps.length - 1}
                    onClick={() => setCurrentStep(i)}
                    aria-label={`Ir para a etapa ${step.title}`}
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                      isActive
                        ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                        : isPassed
                          ? 'bg-emerald-500/50 text-emerald-100 hover:bg-emerald-500/70'
                          : 'bg-slate-800 text-white/30 border border-white/10 hover:bg-slate-700 hover:text-white/70'
                    } ${i === steps.length - 1 ? 'cursor-default' : 'cursor-pointer'}`}
                  >
                    <Icon className="w-4 h-4" />
                  </button>
                  {isActive && <span className="absolute -bottom-6 text-[10px] text-emerald-400 font-medium whitespace-nowrap">{step.title}</span>}
                </div>
              )
            })}
          </div>
        </div>

        {/* Form Body */}
        <div className="flex-1 p-6 mt-4 overflow-y-auto">
          <form onSubmit={handleSubmit} id="wizard-form">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
              >
                {renderStep()}
              </motion.div>
            </AnimatePresence>
          </form>
        </div>

        {/* Footer Actions */}
        <div className="p-6 border-t border-white/10 flex justify-between gap-4 bg-black/20 md:rounded-b-3xl mt-auto">
          <Button
            type="button"
            variant="secondary"
            onClick={prevStep}
            className={`flex-1 ${currentStep === 0 ? 'invisible' : ''}`}
          >
            Anterior
          </Button>

          {currentStep === steps.length - 1 ? (
            <Button type="button" onClick={handleSave} disabled={isSaving} variant="primary" className="flex-1 bg-emerald-500 hover:bg-emerald-600">
              <div className="flex items-center justify-center gap-2">
                <Save className="w-4 h-4" />
                <span>{isSaving ? "Salvando..." : "Salvar Coleta"}</span>
              </div>
            </Button>
          ) : (
            <Button type="button" onClick={nextStep} variant="primary" className="flex-1">
              <div className="flex items-center justify-center gap-2">
                <span>Próximo</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </Button>
          )}
        </div>
      </div>

      {/* Success Modal */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 flex items-center justify-center z-50 bg-black/60 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0, rotate: 180 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className="backdrop-blur-md bg-white/10 border border-white/20 shadow-2xl rounded-3xl p-12 text-center"
            >
              <CheckCircle className="w-24 h-24 text-emerald-400 mx-auto mb-4" />
              <h2 className="text-3xl font-semibold text-white mb-2">
                {initialSample ? "Coleta Atualizada" : "Coleta Registrada"}
              </h2>
              <p className="text-white/70">
                Os dados foram {initialSample ? "atualizados" : "salvos"} com sucesso
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
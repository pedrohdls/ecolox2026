// Tela de autenticação: alterna login/cadastro e encaminha o usuário após sucesso no Supabase.
import { useState } from "react";
import { motion } from "motion/react";
import { toast } from "sonner";
import svgPaths from "@/imports/svg-0qgry0cw7t";
import imgSpiderLogo from "figma:asset/125f7b92600938ab83c27060de9e7545337f21b8.png";
import imgBackground from "figma:asset/e93096631d53aecd7b0622293617c9762e37dfa4.png";
import { supabase } from "@/supabaseClient";

type LoginPageProps = {
  onLogin: () => void;
};

type AuthMode = "login" | "signup";

export function LoginPage({ onLogin }: LoginPageProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<AuthMode>("login");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isSignup = authMode === "signup";

  const getPortugueseErrorMessage = (error: any) => {
    const message = String(error?.message || "").toLowerCase();

    if (message.includes("rate limit exceeded")) {
      return "Muitas tentativas. Aguarde alguns minutos e tente novamente.";
    }

    if (message.includes("invalid login credentials") || message.includes("email or password")) {
      return "Email ou senha inválidos.";
    }

    if (message.includes("user already registered") || message.includes("already registered")) {
      return "Este email já está cadastrado.";
    }

    if (message.includes("signup is disabled")) {
      return "Cadastro temporariamente indisponível.";
    }

    if (message.includes("password should be at least")) {
      return "A senha deve ter pelo menos 6 caracteres.";
    }

    if (message.includes("invalid email")) {
      return "Informe um email válido.";
    }

    return "Não foi possível concluir a operação. Tente novamente.";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validar localmente evita chamadas desnecessárias quando os campos básicos estão vazios.
    if (!email || !password) {
      toast.error("Preencha o email e a senha para continuar.");
      return;
    }

    setIsSubmitting(true);

    try {
      // O modo selecionado define se a operação cria uma conta ou inicia uma sessão.
      if (isSignup) {
        const { error } = await supabase.auth.signUp({
          email,
          password,
        });

        if (error) throw error;

        toast.success("Cadastro realizado com sucesso!");
        onLogin();
        return;
      }

      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      toast.success("Login realizado com sucesso!");
      onLogin();
    } catch (error: any) {
      const message = getPortugueseErrorMessage(error);
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative size-full bg-[#001c0c] overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 flex flex-col items-center justify-end">
        {/* Blur Effect */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[677px] h-[700px]">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 877 900"
          >
            <g filter="url(#filter0_f_1_98)">
              <ellipse
                cx="438.5"
                cy="450"
                fill="#334F53"
                fillOpacity="0.47"
                rx="338.5"
                ry="350"
              />
            </g>
            <defs>
              <filter
                colorInterpolationFilters="sRGB"
                filterUnits="userSpaceOnUse"
                height="900"
                id="filter0_f_1_98"
                width="877"
                x="0"
                y="0"
              >
                <feFlood
                  floodOpacity="0"
                  result="BackgroundImageFix"
                />
                <feBlend
                  in="SourceGraphic"
                  in2="BackgroundImageFix"
                  mode="normal"
                  result="shape"
                />
                <feGaussianBlur
                  result="effect1_foregroundBlur_1_98"
                  stdDeviation="50"
                />
              </filter>
            </defs>
          </svg>
        </div>

        {/* Background Image */}
        <div className="absolute bottom-0 w-[680px] h-[1019px] opacity-20">
          <img
            alt=""
            className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
            src={imgBackground}
          />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6">
        {/* Logo */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{
            delay: 0.2,
            type: "spring",
            stiffness: 200,
          }}
          className="mb-8"
        >
          <div className="relative w-[165px] h-[167px] rounded-full overflow-hidden opacity-90">
            <img
              alt="EcoLox Logo"
              className="absolute inset-0 w-full h-full object-cover"
              src={imgSpiderLogo}
            />
            <div className="absolute inset-0 rounded-full shadow-[inset_0px_3.691px_64.601px_4px_rgba(0,0,0,0.25)]" />
          </div>
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-[#e5ead4] text-[63px] tracking-[19.7px] text-center mb-16 font-['Playfair_Display']"
        >
          ECOLOX
        </motion.h1>

        {/* Subtitle */}
        <motion.h2
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-white text-[32px] text-center mb-12 font-['IBM_Plex_Mono']"
        >
          {isSignup ? "Cadastrar" : "Entrar"}
        </motion.h2>

        {/* Login Form */}
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          onSubmit={handleSubmit}
          className="w-full max-w-[382px] space-y-4"
        >
          {/* Email Input */}
          <div className="relative">
            <div className="flex items-center gap-3 px-4 py-3 bg-white/10 border border-white/20 rounded-xl backdrop-blur-sm">
              <svg
                className="w-6 h-6 flex-shrink-0"
                fill="none"
                viewBox="0 0 24 24"
              >
                <path
                  d={svgPaths.p7ad7900}
                  stroke="#646464"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                />
                <path
                  d={svgPaths.p2eea8bc0}
                  stroke="#646464"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                />
              </svg>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Digite seu email"
                className="flex-1 bg-transparent text-white placeholder-[#5c5c5c] outline-none font-['Anonymous_Pro']"
                required
              />
            </div>
          </div>

          {/* Password Input */}
          <div className="relative">
            <div className="flex items-center gap-3 px-4 py-3 bg-white/10 border border-white/20 rounded-xl backdrop-blur-sm">
              <svg
                className="w-6 h-6 flex-shrink-0"
                fill="none"
                viewBox="0 0 24 24"
              >
                <path
                  d={svgPaths.pdf62e00}
                  stroke="#5C5C5C"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                />
                <path
                  d={svgPaths.p2c300c0}
                  stroke="#5C5C5C"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                />
              </svg>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Digite sua senha"
                className="flex-1 bg-transparent text-white placeholder-[#5c5c5c] outline-none font-['Anonymous_Pro']"
                required
              />
            </div>
          </div>

          {!isSignup && (
            <div className="flex justify-end">
              <button
                type="button"
                className="text-[#e4e4e4] text-[10px] hover:underline font-['Anonymous_Pro']"
              >
                Esqueceu a senha?
              </button>
            </div>
          )}

          <motion.button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-black/70 text-[#6b8c79] py-3 rounded-[20px] text-[24px] font-['Anonymous_Pro'] shadow-[inset_0px_4px_4px_0px_rgba(0,0,0,0.25)] disabled:opacity-70 disabled:cursor-not-allowed"
            whileHover={{
              scale: isSubmitting ? 1 : 1.02,
              backgroundColor: "rgba(0, 0, 0, 0.8)",
            }}
            whileTap={{ scale: isSubmitting ? 1 : 0.98 }}
          >
            {isSubmitting ? "Carregando..." : isSignup ? "Cadastrar" : "Acessar"}
          </motion.button>

          <p className="text-[#bababa] text-[14px] text-center mt-6 font-['Anonymous_Pro']">
            {isSignup ? "Já possui conta?" : "Ainda não possui conta?"}{" "}
            <button
              type="button"
              className="underline hover:text-white transition-colors"
              onClick={() => {
                setAuthMode(isSignup ? "login" : "signup");
                setPassword("");
              }}
            >
              {isSignup ? "Entrar" : "Cadastre-se"}
            </button>
          </p>
        </motion.form>
      </div>
    </div>
  );
}
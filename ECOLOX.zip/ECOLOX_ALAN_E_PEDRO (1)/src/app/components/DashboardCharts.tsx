// Transforma as amostras em contagens agregadas para os gráficos do painel.
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import type { Sample } from '@/app/App';

type Props = {
  samples: Sample[];
};

export function DashboardCharts({ samples }: Props) {
  // Cada bloco agrupa uma variável diferente e preserva a categoria "Não informado".
  
  // 1. Estação do ano
  const seasonCount = samples.reduce((acc, curr) => {
    const s = curr.season || 'Não informado';
    acc[s] = (acc[s] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const seasonData = Object.entries(seasonCount).map(([name, value]) => ({ name, value }));

  // 2. Temperatura
  const tempCount = samples.reduce((acc, curr) => {
    const t = curr.temperature || 'Não informado';
    acc[t] = (acc[t] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const tempData = Object.entries(tempCount).map(([name, value]) => ({ name, value }));

  // 3. Tipo de solo (Pie)
  const soilCount = samples.reduce((acc, curr) => {
    const s = curr.soilType || 'Não informado';
    acc[s] = (acc[s] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const soilData = Object.entries(soilCount).map(([name, value]) => ({ name, value }));

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

  if (samples.length === 0) {
    return <p className="text-center text-white/50 py-12">Sem dados para exibir gráficos</p>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
        <h3 className="text-white/80 font-medium mb-4 text-center">Ocorrência por Estação</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={seasonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" vertical={false} />
              <XAxis dataKey="name" stroke="#ffffff80" fontSize={12} />
              <YAxis stroke="#ffffff80" fontSize={12} allowDecimals={false} />
              <Tooltip cursor={{ fill: '#ffffff10' }} contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
              <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
        <h3 className="text-white/80 font-medium mb-4 text-center">Ocorrência por Temperatura</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={tempData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" vertical={false} />
              <XAxis dataKey="name" stroke="#ffffff80" fontSize={12} />
              <YAxis stroke="#ffffff80" fontSize={12} allowDecimals={false} />
              <Tooltip cursor={{ fill: '#ffffff10' }} contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
              <Bar dataKey="value" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="p-4 rounded-2xl bg-white/5 border border-white/10 md:col-span-2">
        <h3 className="text-white/80 font-medium mb-4 text-center">Distribuição por Tipo de Solo</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={soilData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {soilData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
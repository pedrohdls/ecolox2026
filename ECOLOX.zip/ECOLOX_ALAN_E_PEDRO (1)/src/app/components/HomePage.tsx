// Painel científico: reúne indicadores, mapa, consulta filtrável e gráficos das coletas.
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Plus, Leaf, Map, LayoutDashboard, Table as TableIcon, BarChart3, LogOut } from "lucide-react";
import { SampleCard } from "@/app/components/SampleCard";
import { Button } from "@/app/components/Button";
import { LeafletMap } from "@/app/components/LeafletMap";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/app/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/app/components/ui/dialog";
import type { Sample } from "@/app/App";

import { DashboardCharts } from "@/app/components/DashboardCharts";

type HomePageProps = {
  samples: Sample[];
  onNavigateToNew: () => void;
  onEditSample: (sample: Sample) => void;
  onDeleteSample: (sampleId: string) => void;
  onDownloadSample: (sample: Sample) => void;
  onLogout: () => void;
  onNavigateToAbout: () => void;
};

const sampleFieldLabels: Record<string, string> = {
  id: "Identificação",
  date: "Data",
  time: "Hora",
  researcher: "Pesquisador responsável",
  incomingSpiders: "Entrada de aranhas",
  outgoingSpiders: "Saída de aranhas",
  balanceSpiders: "Saldo de aranhas",
  ownerName: "Nome do proprietário",
  ownerPhone: "Telefone do proprietário",
  ownerAddress: "Endereço do proprietário",
  ownerCity: "Cidade",
  ownerNeighborhood: "Bairro",
  ownerReference: "Ponto de referência",
  latitude: "Latitude",
  longitude: "Longitude",
  sunlight: "Insolação",
  temperature: "Temperatura",
  humidity: "Umidade",
  vegetation: "Vegetação",
  soilType: "Tipo de solo",
  climate: "Clima",
  season: "Estação",
  month: "Mês",
  shedAge: "Idade do galpão",
  frequencyOfUse: "Frequência de uso",
  architecturalDetails: "Detalhes arquitetônicos",
  roofMaterial: "Material do teto",
  wallMaterial: "Material da parede",
  luminosity: "Luminosidade",
  floorMaterial: "Material do chão",
  airyEnvironment: "Ambiente arejado",
  substrateMaterial: "Material do substrato",
  closedAreaSize: "Área fechada",
  height: "Altura",
  constructionObservations: "Observações da construção",
  farmAnimals: "Animais de criação",
  farmAnimalType: "Tipo de animal",
  otherSpidersPresence: "Presença de outras aranhas",
  otherSpidersType: "Quais outras aranhas",
  preyPresence: "Presença de presas",
  predatorPresence: "Presença de predadores",
  biologicalObservations: "Observações biológicas",
};

export function HomePage({
  samples,
  onNavigateToNew,
  onEditSample,
  onDeleteSample,
  onDownloadSample,
  onLogout,
  onNavigateToAbout,
}: HomePageProps) {
  // O estado controla o filtro da consulta e o modal de detalhes da amostra selecionada.
  const [filterCity, setFilterCity] = useState("");
  const [selectedSample, setSelectedSample] = useState<Sample | null>(null);
  const [activeTab, setActiveTab] = useState("dashboard");
  
  const totalAranhas = samples.reduce((acc, curr) => acc + (curr.balanceSpiders || 0), 0);

  // Filtrar localmente mantém a consulta rápida sem uma nova chamada ao banco a cada tecla.
  const filteredSamples = samples.filter(s => 
    s.ownerCity.toLowerCase().includes(filterCity.toLowerCase())
  );

  return (
    <motion.div
      className="min-h-screen w-full p-4 md:p-8 max-w-7xl mx-auto"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3 }}
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl backdrop-blur-md bg-emerald-500/20 border border-emerald-400/30">
            <Leaf className="w-8 h-8 text-emerald-300" />
          </div>
          <div>
            <h1 className="text-3xl font-semibold text-white tracking-tight">
              EcoLox
            </h1>
            <p className="text-white/70 text-sm mt-1">
              Painel de Dados Científicos
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-3">
          {activeTab === "dashboard" && (
            <Button onClick={onNavigateToAbout} variant="secondary">
              Saiba mais
            </Button>
          )}
          <Button onClick={onNavigateToNew} variant="primary" className="shadow-lg shadow-emerald-500/20">
            <div className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              <span>Nova Coleta</span>
            </div>
          </Button>
          <Button onClick={onLogout} variant="secondary">
            <div className="flex items-center gap-2">
              <LogOut className="w-5 h-5" />
              <span>Sair</span>
            </div>
          </Button>
        </div>
      </motion.div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3 bg-white/10 border border-white/20 backdrop-blur-md p-1 rounded-xl mb-6">
          <TabsTrigger value="dashboard" className="rounded-lg data-[state=active]:bg-emerald-500/80 data-[state=active]:text-white text-white/70">
            <LayoutDashboard className="w-4 h-4 mr-2" /> Visão Geral
          </TabsTrigger>
          <TabsTrigger value="consulta" className="rounded-lg data-[state=active]:bg-emerald-500/80 data-[state=active]:text-white text-white/70">
            <TableIcon className="w-4 h-4 mr-2" /> Consulta
          </TabsTrigger>
          <TabsTrigger value="estatisticas" className="rounded-lg data-[state=active]:bg-emerald-500/80 data-[state=active]:text-white text-white/70">
            <BarChart3 className="w-4 h-4 mr-2" /> Análises
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6 outline-none">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-6 rounded-2xl backdrop-blur-md bg-white/10 border border-white/20">
              <h3 className="text-white/70 text-sm font-medium mb-2">Pontos Amostrais</h3>
              <p className="text-4xl text-white font-bold">{samples.length}</p>
            </div>
            <div className="p-6 rounded-2xl backdrop-blur-md bg-white/10 border border-white/20">
              <h3 className="text-white/70 text-sm font-medium mb-2">Total de Coletas</h3>
              <p className="text-4xl text-white font-bold">{samples.length}</p>
            </div>
            <div className="p-6 rounded-2xl backdrop-blur-md bg-white/10 border border-white/20">
              <h3 className="text-white/70 text-sm font-medium mb-2">Aranhas Registradas</h3>
              <p className="text-4xl text-emerald-400 font-bold">{totalAranhas}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Map */}
            <div className="lg:col-span-2 p-4 rounded-2xl backdrop-blur-md bg-white/10 border border-white/20">
              <h3 className="text-lg text-white font-medium mb-4 flex items-center gap-2">
                <Map className="w-5 h-5 text-emerald-400" />
                Mapa de Ocorrências
              </h3>
              <LeafletMap mode="view" samples={samples} height="400px" />
            </div>

            {/* Last Collections */}
            <div className="p-4 rounded-2xl backdrop-blur-md bg-white/10 border border-white/20 flex flex-col">
              <h3 className="text-lg text-white font-medium mb-4">Últimas Coletas</h3>
              <div className="flex-1 overflow-y-auto space-y-4 max-h-[400px] pr-2">
                {samples.slice(0, 5).map((sample, index) => (
                  <SampleCard
                    key={sample.id}
                    sample={sample}
                    index={index}
                    onEdit={onEditSample}
                    onDownload={onDownloadSample}
                  />
                ))}
                {samples.length === 0 && (
                  <p className="text-white/50 text-sm text-center py-8">Nenhuma coleta registrada.</p>
                )}
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="consulta" className="outline-none">
          <div className="p-6 rounded-2xl backdrop-blur-md bg-white/10 border border-white/20 overflow-x-auto">
            <div className="mb-4 flex items-center gap-4">
              <input 
                type="text" 
                placeholder="Filtrar por cidade..." 
                value={filterCity}
                onChange={e => setFilterCity(e.target.value)}
                className="px-4 py-2 rounded-xl bg-black/20 border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/20 text-white/70">
                  <th className="py-3 px-4 font-medium text-sm">ID</th>
                  <th className="py-3 px-4 font-medium text-sm">Data</th>
                  <th className="py-3 px-4 font-medium text-sm">Cidade</th>
                  <th className="py-3 px-4 font-medium text-sm">Bairro</th>
                  <th className="py-3 px-4 font-medium text-sm">Proprietário</th>
                  <th className="py-3 px-4 font-medium text-sm">Saldo Aranhas</th>
                  <th className="py-3 px-4 font-medium text-sm">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredSamples.map(sample => (
                  <tr
                    key={sample.id}
                    className="border-b border-white/10 hover:bg-white/5 transition-colors cursor-pointer"
                    onClick={() => setSelectedSample(sample)}
                  >
                    <td className="py-3 px-4 text-white/90 text-sm">{sample.id}</td>
                    <td className="py-3 px-4 text-white/90 text-sm">{sample.date}</td>
                    <td className="py-3 px-4 text-white/90 text-sm">{sample.ownerCity}</td>
                    <td className="py-3 px-4 text-white/90 text-sm">{sample.ownerNeighborhood}</td>
                    <td className="py-3 px-4 text-white/90 text-sm">{sample.ownerName}</td>
                    <td className="py-3 px-4 text-white/90 text-sm">{sample.balanceSpiders}</td>
                    <td className="py-3 px-4 text-white/90 text-sm">
                      <div className="flex gap-2">
                        <button
                          onClick={(event) => {
                            event.stopPropagation();
                            onEditSample(sample);
                          }}
                          className="text-emerald-400 hover:text-emerald-300 text-xs"
                        >
                          Editar
                        </button>
                        <button
                          onClick={(event) => {
                            event.stopPropagation();
                            onDownloadSample(sample);
                          }}
                          className="text-cyan-400 hover:text-cyan-300 text-xs"
                        >
                          Baixar
                        </button>
                        <button
                          onClick={(event) => {
                            event.stopPropagation();
                            if (window.confirm(`Excluir a coleta ${sample.id}?`)) {
                              onDeleteSample(sample.id);
                            }
                          }}
                          className="text-red-400 hover:text-red-300 text-xs"
                        >
                          Excluir
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredSamples.length === 0 && (
              <p className="text-center text-white/50 py-8">Nenhum resultado encontrado.</p>
            )}
          </div>
        </TabsContent>

        <Dialog open={selectedSample !== null} onOpenChange={(open) => !open && setSelectedSample(null)}>
          <DialogContent className="max-h-[90vh] max-w-4xl overflow-y-auto bg-slate-950/95 text-white border-white/20">
            <DialogHeader>
              <DialogTitle className="text-xl text-white">
                Detalhes completos da coleta {selectedSample?.id}
              </DialogTitle>
            </DialogHeader>
          
            {selectedSample && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                
                {Object.entries(selectedSample).map(([key, value]) => (
                  <div key={key} className="rounded-lg bg-white/5 border border-white/10 p-3">
                    <p className="text-emerald-300 font-medium mb-1">{sampleFieldLabels[key] || key}</p>
                    <p className="text-white/80 whitespace-pre-wrap break-words">
                      {typeof value === "object" ? JSON.stringify(value, null, 2) : String(value ?? "-")}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </DialogContent>
        </Dialog>

        <TabsContent value="estatisticas" className="outline-none">
          <div className="p-6 rounded-2xl backdrop-blur-md bg-white/10 border border-white/20">
            <div className="flex items-center gap-3 mb-6">
              <BarChart3 className="w-6 h-6 text-emerald-400" />
              <h2 className="text-xl font-medium text-white">Análise de Ocorrências</h2>
            </div>
            <DashboardCharts samples={samples} />
          </div>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}
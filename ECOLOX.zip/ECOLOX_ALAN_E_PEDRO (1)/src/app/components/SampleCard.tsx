// Cartão resumido de uma coleta: exibe métricas principais e ações de editar e baixar.
import { motion } from "motion/react";
import {
  Thermometer,
  Droplets,
  Mountain,
  MapPin,
  Calendar,
  Eye,
  Download,
  Edit,
} from "lucide-react";
import type { Sample } from "@/app/App";

type SampleCardProps = {
  sample: Sample;
  index: number;
  onEdit?: (sample: Sample) => void;
  onDownload?: (sample: Sample) => void;
};

export function SampleCard({
  sample,
  index,
  onEdit,
  onDownload,
}: SampleCardProps) {
  // As ações param a propagação para não confundir clique em botão com seleção do cartão.
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="group relative overflow-hidden rounded-2xl backdrop-blur-md bg-white/10 border border-white/20 p-6 hover:bg-white/15 transition-all duration-300 shadow-xl cursor-pointer"
      whileHover={{ scale: 1.02, y: -4 }}
      whileTap={{ scale: 0.98 }}
    >
      {/* Hover Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/0 to-emerald-500/0 group-hover:from-emerald-500/10 group-hover:to-cyan-500/10 transition-all duration-300 pointer-events-none" />

      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl text-white mb-1">
              Coleta {sample.id}
            </h3>
            <div className="flex items-center gap-2 text-white/70 text-sm">
              <Calendar className="w-4 h-4" />
              <span>{sample.date}</span>
            </div>
          </div>
          <motion.div
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
            className="p-2 rounded-lg bg-white/10"
          >
            <Eye className="w-4 h-4 text-white/60" />
          </motion.div>
        </div>

        {/* Location */}
        <div className="flex items-start gap-2 mb-4 text-white/80 text-sm">
          <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <div>
            <p>{sample.ownerCity} - {sample.ownerNeighborhood}</p>
            <p className="text-white/60 text-xs mt-1">
              Proprietário: {sample.ownerName}
            </p>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-3 gap-4">
          {/* Temperature */}
          <motion.div
            className="flex flex-col items-center p-3 rounded-xl bg-white/5 border border-white/10"
            whileHover={{
              scale: 1.05,
              backgroundColor: "rgba(255, 255, 255, 0.1)",
            }}
          >
            <Thermometer className="w-5 h-5 text-red-400 mb-2" />
            <span className="text-white text-lg">
              {sample.temperature}
            </span>
            <span className="text-white/60 text-xs mt-1">
              Temperatura
            </span>
          </motion.div>

          {/* Humidity */}
          <motion.div
            className="flex flex-col items-center p-3 rounded-xl bg-white/5 border border-white/10"
            whileHover={{
              scale: 1.05,
              backgroundColor: "rgba(255, 255, 255, 0.1)",
            }}
          >
            <Droplets className="w-5 h-5 text-blue-400 mb-2" />
            <span className="text-white text-lg">
              {sample.humidity}
            </span>
            <span className="text-white/60 text-xs mt-1">
              Umidade
            </span>
          </motion.div>

          {/* Soil Type */}
          <motion.div
            className="flex flex-col items-center p-3 rounded-xl bg-white/5 border border-white/10"
            whileHover={{
              scale: 1.05,
              backgroundColor: "rgba(255, 255, 255, 0.1)",
            }}
          >
            <Mountain className="w-5 h-5 text-amber-400 mb-2" />
            <span className="text-white text-sm">
              {sample.soilType}
            </span>
            <span className="text-white/60 text-xs mt-1">
              Solo
            </span>
          </motion.div>
        </div>

        {/* Action Buttons */}
        <div className="mt-4 flex gap-2">
          <motion.button
            onClick={(e) => {
              e.stopPropagation();
              onEdit?.(sample);
            }}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white/80 hover:text-white transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Edit className="w-4 h-4" />
            <span className="text-sm">Editar</span>
          </motion.button>
          <motion.button
            onClick={(e) => {
              e.stopPropagation();
              onDownload?.(sample);
            }}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/30 text-emerald-200 hover:text-emerald-100 transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Download className="w-4 h-4" />
            <span className="text-sm">Baixar</span>
          </motion.button>
        </div>

        {/* Sunlight Badge */}
        <div className="mt-4 flex justify-end">
          <motion.span
            className={`px-3 py-1 rounded-full text-xs ${
              sample.sunlight === "Alta"
                ? "bg-yellow-500/30 text-yellow-200 border border-yellow-400/30"
                : sample.sunlight === "Média"
                  ? "bg-orange-500/30 text-orange-200 border border-orange-400/30"
                  : "bg-slate-500/30 text-slate-200 border border-slate-400/30"
            }`}
            whileHover={{ scale: 1.1 }}
          >
            Insolação: {sample.sunlight}
          </motion.span>
        </div>
      </div>
    </motion.div>
  );
}
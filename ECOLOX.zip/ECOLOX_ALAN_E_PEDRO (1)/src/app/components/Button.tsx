// Botão visual compartilhado pelas telas principais, com variantes de estilo do produto.
import { motion } from "motion/react";
import { ReactNode } from "react";

type ButtonProps = {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "success";
  disabled?: boolean;
  type?: "button" | "submit";
  form?: string;
  className?: string;
};

export function Button({
  children,
  onClick,
  variant = "primary",
  disabled = false,
  type = "button",
  form,
  className = "",
}: ButtonProps) {
  const baseClasses =
    "px-6 py-3 rounded-xl font-medium transition-all duration-200 backdrop-blur-md";

  const variantClasses = {
    primary:
      "bg-emerald-500/80 hover:bg-emerald-400/90 text-white shadow-lg shadow-emerald-500/20",
    secondary:
      "bg-white/10 hover:bg-white/20 text-white border border-white/30",
    success:
      "bg-green-500/80 hover:bg-green-400/90 text-white shadow-lg shadow-green-500/20",
  };

  const disabledClasses = "opacity-50 cursor-not-allowed";

  return (
    <motion.button
      type={type}
      form={form}
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${variantClasses[variant]} ${disabled ? disabledClasses : ""} ${className}`}
      whileHover={!disabled ? { scale: 1.02 } : {}}
      whileTap={!disabled ? { scale: 0.98 } : {}}
      transition={{
        type: "spring",
        stiffness: 400,
        damping: 17,
      }}
    >
      {children}
    </motion.button>
  );
}
// Mapa compartilhado pelo cadastro (seleção de coordenadas) e pelo painel (marcadores das coletas).
import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { Sample } from '@/app/App';

const markerHtml = `<div style="background-color: #2D6A4F; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 4px rgba(0,0,0,0.5);"></div>`;

const customIcon = L.divIcon({
  className: 'custom-div-icon',
  html: markerHtml,
  iconSize: [16, 16],
  iconAnchor: [8, 8]
});

function isValidCoordinate(latitude: unknown, longitude: unknown): latitude is number {
  const numericLatitude = Number(latitude);
  const numericLongitude = Number(longitude);

  return Number.isFinite(numericLatitude)
    && Number.isFinite(numericLongitude)
    && numericLatitude >= -90
    && numericLatitude <= 90
    && numericLongitude >= -180
    && numericLongitude <= 180;
}

type MapProps = {
  mode: 'picker' | 'view';
  samples?: Sample[];
  defaultLat?: number;
  defaultLng?: number;
  onLocationSelect?: (lat: number, lng: number) => void;
  height?: string;
};

export function LeafletMap({
  mode,
  samples = [],
  defaultLat = -24.5833, // Iporanga base
  defaultLng = -48.5833,
  onLocationSelect,
  height = '300px'
}: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);

  useEffect(() => {
    // O mapa Leaflet é criado uma vez e recebe marcadores conforme modo e amostras mudam.
    if (!mapRef.current) return;

    if (!mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapRef.current).setView([defaultLat, defaultLng], 12);
      
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19
      }).addTo(mapInstanceRef.current);
    }

    const map = mapInstanceRef.current;
    const validSamples = samples.filter(sample =>
      isValidCoordinate(sample.latitude, sample.longitude)
    );

    // Clear existing markers if re-rendering samples
    map.eachLayer((layer) => {
      if (layer instanceof L.Marker) {
        map.removeLayer(layer);
      }
    });

    // No modo picker, eventos de clique e arraste devolvem coordenadas ao formulário.
    if (mode === 'picker') {
      markerRef.current = L.marker([defaultLat, defaultLng], { draggable: true, icon: customIcon }).addTo(map);
      map.panTo([defaultLat, defaultLng]);
      
      markerRef.current.on('dragend', function (event) {
        const marker = event.target;
        const position = marker.getLatLng();
        onLocationSelect?.(position.lat, position.lng);
      });

      map.on('click', function(e) {
        markerRef.current?.setLatLng(e.latlng);
        onLocationSelect?.(e.latlng.lat, e.latlng.lng);
      });
    // No modo view, cada amostra vira um marcador e o mapa enquadra todos os pontos.
    } else if (mode === 'view') {
      const markers = validSamples.map(sample => {
        const marker = L.marker([Number(sample.latitude), Number(sample.longitude)], { icon: customIcon })
          .bindPopup(`<b>${sample.ownerCity}</b><br/>${sample.date}`)
          .addTo(map);
        return marker;
      });
      
      if (markers.length > 0) {
        const group = new L.FeatureGroup(markers);
        map.fitBounds(group.getBounds(), { padding: [50, 50] });
      }
    }

    return () => {
      // Map cleanup handled by react unmount for simple views
    };
  }, [mode, samples, defaultLat, defaultLng]);

  return <div ref={mapRef} style={{ height, width: '100%', borderRadius: '12px', zIndex: 0 }} />;
}

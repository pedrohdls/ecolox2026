// Componente raiz: controla a tela atual, carrega as amostras e coordena as operações do sistema.
import { useState, useEffect } from "react";
import { AnimatePresence } from "motion/react";
import { Toaster } from "@/app/components/ui/sonner";
import { LoginPage } from "@/app/components/LoginPage";
import { AboutPage } from "@/app/components/AboutPage";
import { HomePage } from "@/app/components/HomePage";
import { NewSamplePage } from "@/app/components/NewSamplePage";
import { toast } from "sonner";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { createSample, fetchAllSamples, updateSample, deleteSample } from "@/services/sampleService";
import { testSupabaseConnection } from "@/services/testConnection";
import { supabase } from "@/supabaseClient";
window.testSupabaseConnection = testSupabaseConnection;

const sampleFieldLabels: Record<keyof Sample, string> = {
  id: "Identificação",
  date: "Data",
  time: "Hora",
  researcher: "Pesquisador responsável",
  incomingSpiders: "Entrada de aranhas",
  outgoingSpiders: "Saída de aranhas",
  balanceSpiders: "Saldo de aranhas",
  ownerName: "Nome do proprietário",
  ownerPhone: "Telefone do proprietário",
  ownerAddress: "Endereço do proprietário",
  ownerCity: "Cidade",
  ownerNeighborhood: "Bairro",
  ownerReference: "Ponto de referência",
  latitude: "Latitude",
  longitude: "Longitude",
  sunlight: "Insolação",
  temperature: "Temperatura",
  humidity: "Umidade",
  vegetation: "Vegetação",
  soilType: "Tipo de solo",
  climate: "Clima",
  season: "Estação",
  month: "Mês",
  shedAge: "Idade do galpão",
  frequencyOfUse: "Frequência de uso",
  architecturalDetails: "Detalhes arquitetônicos",
  roofMaterial: "Material do teto",
  wallMaterial: "Material da parede",
  luminosity: "Luminosidade",
  floorMaterial: "Material do chão",
  airyEnvironment: "Ambiente arejado",
  substrateMaterial: "Material do substrato",
  closedAreaSize: "Área fechada",
  height: "Altura",
  constructionObservations: "Observações da construção",
  farmAnimals: "Animais de criação",
  farmAnimalType: "Tipo de animal",
  otherSpidersPresence: "Presença de outras aranhas",
  otherSpidersType: "Quais outras aranhas",
  preyPresence: "Presença de presas",
  predatorPresence: "Presença de predadores",
  biologicalObservations: "Observações biológicas",
};


export type Sample = {
  id: string;
  // Identificação
  date: string;
  time: string;
  researcher: string;
  incomingSpiders: number;
  outgoingSpiders: number;
  balanceSpiders: number;
  
  // Dados do Proprietário
  ownerName: string;
  ownerPhone: string;
  ownerAddress: string;
  ownerCity: string;
  ownerNeighborhood: string;
  ownerReference: string;
  latitude: number;
  longitude: number;
  
  // Variáveis Ambientais
  sunlight: string;
  temperature: string;
  humidity: string;
  vegetation: string;
  soilType: string;
  climate: string;
  season: string;
  month: string;
  
  // Características da Construção
  shedAge: string;
  frequencyOfUse: string;
  architecturalDetails: string[];
  roofMaterial: string;
  wallMaterial: string;
  luminosity: string;
  floorMaterial: string;
  airyEnvironment: string;
  substrateMaterial: string[];
  closedAreaSize: string;
  height: string;
  constructionObservations: string;
  
  // Variáveis Bióticas
  farmAnimals: string;
  farmAnimalType: string;
  otherSpidersPresence: string;
  otherSpidersType: string;
  preyPresence: string[];
  predatorPresence: string[];
  biologicalObservations: string;
  
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<
    "login" | "about" | "home" | "new"
  >("login");
  const [samples, setSamples] = useState<Sample[]>([]);
  const [editingSample, setEditingSample] = useState<Sample | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthLoading, setIsAuthLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    const restoreSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();

      if (isMounted) {
        setCurrentPage(session ? "home" : "login");
        setIsAuthLoading(false);
      }
    };

    restoreSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        if (isMounted) {
          setCurrentPage(session ? "home" : "login");
        }
      },
    );

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  // Carregar dados do Supabase quando o app inicia
  useEffect(() => {
    // A lista é carregada uma vez ao iniciar o app para alimentar o painel, mapa e gráficos.
    const loadSamples = async () => {
      try {
        setIsLoading(true);
        const data = await fetchAllSamples();
        setSamples(data);
      } catch (error) {
        console.error("Erro ao carregar amostras:", error);
        toast.error("Erro ao carregar dados do servidor");
      } finally {
        setIsLoading(false);
      }
    };

    loadSamples();
  }, []);

  if (isAuthLoading) {
    return null;
  }

  const handleAddSample = async (sample: Sample) => {
    try {
      // O ID existente identifica edição; um ID ausente ou novo identifica cadastro.
      const isEditing = samples.some(existingSample => existingSample.id === sample.id);

      if (isEditing) {
        await updateSample(sample);
        setSamples(samples.map(existingSample =>
          existingSample.id === sample.id ? sample : existingSample
        ));
        toast.success("Coleta atualizada com sucesso!");
      } else {
        if (!sample.id) {
          sample.id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        }
        await createSample(sample);
        setSamples([sample, ...samples]);
        toast.success("Coleta salva com sucesso no banco de dados!");
      }

      setEditingSample(null);
      setCurrentPage("home");
    } catch (error) {
      console.error("Erro ao salvar coleta:", error);
      const supabaseError = error as { message?: string; code?: string; details?: string; hint?: string };
      const message = supabaseError?.message || "Erro desconhecido";
      const context = [supabaseError?.code, supabaseError?.details].filter(Boolean).join(" - ");
      toast.error(`Erro ao salvar coleta: ${message}${context ? ` (${context})` : ""}`);
      throw error;
    }
  };

  const handleEditSample = (sample: Sample) => {
    // Guardar a amostra selecionada faz o formulário abrir preenchido e em modo de edição.
    setEditingSample(sample);
    setCurrentPage("new");
  };

  const handleCancelSample = () => {
    // Cancelar também limpa o contexto de edição para a próxima coleta começar vazia.
    setEditingSample(null);
    setCurrentPage("home");
  };

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();

    if (error) {
      console.error("Erro ao sair:", error);
      toast.error("Não foi possível sair. Tente novamente.");
      return;
    }

    setEditingSample(null);
  };

  const handleDeleteSample = async (sampleId: string) => {
    try {
      await deleteSample(sampleId);
      setSamples(samples.filter(s => s.id !== sampleId));
      toast.success("Coleta deletada com sucesso!");
    } catch (error) {
      console.error("Erro ao deletar coleta:", error);
      toast.error("Erro ao deletar coleta. Tente novamente.");
    }
  };
  const handleDownloadSample = (sample: Sample) => {
    const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const rows = (Object.keys(sampleFieldLabels) as Array<keyof Sample>).map((field) => {
      const value = sample[field];
      const formattedValue = Array.isArray(value) ? value.join(", ") : String(value ?? "Não informado");

      return [sampleFieldLabels[field], formattedValue || "Não informado"];
    });

    pdf.setFontSize(16);
    pdf.text("Ficha da amostra EcoLox", 14, 16);
    pdf.setFontSize(10);
    pdf.setTextColor(90);
    pdf.text(`Amostra ${sample.id}`, 14, 23);
    pdf.setTextColor(0);

    autoTable(pdf, {
      startY: 29,
      head: [["Variável", "Valor"]],
      body: rows,
      theme: "grid",
      styles: {
        font: "helvetica",
        fontSize: 9,
        cellPadding: 3,
        overflow: "linebreak",
        valign: "top",
      },
      headStyles: {
        fillColor: [22, 101, 52],
        textColor: 255,
        fontStyle: "bold",
      },
      columnStyles: {
        0: { cellWidth: 58, fontStyle: "bold" },
        1: { cellWidth: "auto" },
      },
      alternateRowStyles: {
        fillColor: [242, 248, 244],
      },
      margin: { left: 14, right: 14 },
    });

    const safeDate = sample.date.replace(/[\\/]/g, "-");
    pdf.save(`coleta_${sample.id}_${safeDate}.pdf`);
    toast.success(`Download iniciado: ${sample.id}`);
  };

  const backgroundImage =
    "https://images.unsplash.com/photo-1733937440188-6c61d7a3759e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwZm9yZXN0JTIwbmF0dXJlJTIwZ3JlZW58ZW58MXx8fHwxNzY5MzAzMDY0fDA&ixlib=rb-4.1.0&q=80&w=1080";

  // Don't show background for the login page.
  const showBackground = currentPage !== "login";

  return (
    <div
      className={`relative min-h-screen w-full overflow-hidden ${showBackground ? "bg-cover bg-center" : ""}`}
      style={
        showBackground
          ? {
              backgroundImage: `url(${backgroundImage})`,
            }
          : {}
      }
    >
      {/* Overlay escuro - only for pages with background */}
      {showBackground && (
        <div className="absolute inset-0 bg-black/40" />
      )}

      {/* Toaster for notifications */}
      <Toaster />

      {/* Conteúdo */}
      <div className="relative z-10">
        <AnimatePresence mode="wait">
          {currentPage === "login" ? (
            <LoginPage
              key="login"
              onLogin={() => setCurrentPage("home")}
            />
          ) : currentPage === "about" ? (
            <AboutPage
              key="about"
              onBack={() => setCurrentPage("home")}
              onLogout={handleLogout}
            />
          ) : currentPage === "home" ? (
            <HomePage
              key="home"
              samples={samples}
              onNavigateToNew={() => {
                setEditingSample(null);
                setCurrentPage("new");
              }}
              onEditSample={handleEditSample}
              onDeleteSample={handleDeleteSample}
              onDownloadSample={handleDownloadSample}
              onLogout={handleLogout}
              onNavigateToAbout={() => setCurrentPage("about")}
            />
          ) : (
            <NewSamplePage
              key={`new-${editingSample?.id ?? "new"}`}
              onSave={handleAddSample}
              initialSample={editingSample}
              onCancel={handleCancelSample}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

  // Ponto de entrada do frontend: monta o componente raiz e carrega os estilos globais.
  import { createRoot } from "react-dom/client";
  import App from "./app/App.tsx";
  import "./styles/index.css";

// O elemento `root` é definido no index.html e recebe toda a árvore React.
createRoot(document.getElementById("root")!).render(<App />);
  
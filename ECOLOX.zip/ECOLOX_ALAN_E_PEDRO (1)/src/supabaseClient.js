// Configura o cliente único usado pelo frontend para autenticação e acesso ao Supabase.
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://pxdhpozrcwdbadrzzpkm.supabase.co";

const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB4ZGhwb3pyY3dkYmFkcnp6cGttIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY1NTAyODksImV4cCI6MjEwMjEyNjI4OX0.TUrMUnRc15HGDEkuLkmjTmeuRuoa4MiJEefIfKcxcdc";

if (!supabaseAnonKey.startsWith("eyJ")) {
  console.error(" ERRO: A chave anônima deve começar com 'eyJ', não com 'sb_secret_'");
  console.error("Obtenha a chave correta em: Settings → API → anon public");
}

// O cliente é exportado para que os serviços e a tela de login compartilhem a mesma conexão.
export const supabase = createClient(supabaseUrl, supabaseAnonKey);


Para o Figma Make, o ideal não é pedir apenas uma "tabela digital". A IA tende a produzir resultados melhores quando recebe uma especificação completa de produto, descrevendo estrutura, fluxo, componentes, responsividade, validações e comportamento dos dados.

Eu modelaria esse sistema como uma aplicação de coleta científica de campo, semelhante a um formulário de inspeção ambiental, mantendo a lógica da ficha original, mas transformando os códigos numéricos em seletores visuais.

Prompt para Figma Make:

---

Crie um protótipo funcional e responsivo de um sistema web SaaS para coleta de dados científicos de micro-hábitats de aranhas do gênero Loxosceles.

O objetivo do sistema é substituir fichas de campo em papel por um formulário digital intuitivo, responsivo e organizado para pesquisadores.

Utilize um design moderno, profissional e científico, semelhante a aplicações como Google Forms, Airtable, Notion e ArcGIS Survey123.

Paleta de cores:

* Verde escuro (#1B4332)
* Verde médio (#2D6A4F)
* Verde claro (#95D5B2)
* Branco
* Cinza claro para fundos

Tipografia:

* Inter
* Layout clean
* Espaçamento generoso
* Componentes acessíveis para uso em celulares durante trabalho de campo

Estrutura do sistema:

# Dashboard Principal

Exibir:

* Total de pontos amostrais cadastrados
* Total de coletas realizadas
* Total de aranhas registradas
* Mapa com pontos georreferenciados
* Últimas coletas realizadas

Botão principal:

"Nova Coleta"

---

# Cadastro do Ponto Amostral

Seção:

Dados do Proprietário

Campos:

* Nome completo
* Telefone
* Endereço completo
* Cidade
* Bairro
* Ponto de referência
* Coordenadas geográficas

Adicionar botão:

"Capturar localização GPS"

Mostrar mapa interativo com marcador.

---

# Formulário de Coleta

Organizar em etapas (Wizard / Stepper)

Etapa 1:
Identificação da coleta

Campos:

* Data
* Hora
* Pesquisador responsável
* Entrada de aranhas
* Saída de aranhas
* Saldo de aranhas

---

Etapa 2:
Variáveis Ambientais

Exibir em formato de cartões selecionáveis.

Insolação:

* Baixa
* Média
* Alta

Temperatura:

* Baixa
* Média
* Intensa

Umidade:

* Baixa
* Média
* Intensa

Vegetação:

* Pouca
* Mediana
* Abundante

Tipo de Solo:

* Seco
* Arenoso
* Barro Vermelho
* Argiloso
* Calcário

Clima:

* Ensolarado
* Sol com nuvens
* Nublado
* Nevoeiro
* Chuva
* Tempestade

Estação:

* Verão
* Outono
* Inverno
* Primavera

Mês:

* Janeiro até Dezembro

---

Etapa 3:
Características da Construção

Campos:

Idade do galpão:

* 1 a 5 anos
* 5 a 10 anos
* 10 a 20 anos
* 20 a 30 anos
* Mais de 30 anos

Frequência de uso:

* Mensal
* Semanal
* Diária

Detalhes arquitetônicos:
Checkbox múltiplo

* Porão
* Sótão
* Frestas
* Espaço aberto

Material do teto:

* Metal
* Telha
* Laje
* Eternit

Material da parede:

* Madeira
* Concreto
* Metal
* Tijolo

Luminosidade:

* Sem iluminação
* Baixa
* Alta
* Luz natural

Material do chão:

* Piso
* Madeira
* Concreto
* Tijolo
* Grama
* Solo

Ambiente arejado:

* Sim
* Não

Material do substrato:
Checkbox múltiplo

* Palha
* Madeira
* Papelão
* Plástico
* Grãos
* Metais
* Sacos de ração
* Serragem

Tamanho da área fechada:

* Pequena
* Média
* Grande

Altura:

* Até 2m
* Até 2,5m
* Até 3m
* Até 3,5m

Adicionar campo:

Observações da construção

---

Etapa 4:
Variáveis Bióticas

Presença de animais de criação:

* Sim
* Não

Se sim:
Exibir campo:
Tipo do animal

Presença de outras aranhas:

* Sim
* Não

Presença de presas:
Checkbox múltiplo

* Baratas
* Grilos
* Moscas
* Mariposas
* Outros insetos

Presença de predadores:
Checkbox múltiplo

* Anfíbios
* Répteis
* Aves
* Roedores
* Insetos

Campo:

Observações biológicas

---

Etapa 5:
Registro Fotográfico

Permitir:

* Upload de imagens
* Captura por câmera
* Visualização em galeria

Categorias:

* Ambiente externo
* Ambiente interno
* Aranhas encontradas
* Estruturas da construção

---

Etapa 6:
Resumo

Exibir todas as informações preenchidas.

Botões:

* Editar
* Salvar rascunho
* Finalizar coleta

Ao finalizar:

Mostrar mensagem:

"Coleta registrada com sucesso"

---

# Tela de Consulta

Criar tabela responsiva com filtros.

Filtros:

* Cidade
* Bairro
* Data
* Estação do ano
* Tipo de solo
* Clima
* Presença de presas
* Presença de predadores

Colunas:

* ID
* Data
* Cidade
* Bairro
* Proprietário
* Coordenadas
* Saldo de aranhas
* Ações

Ações:

* Visualizar
* Editar
* Excluir

---

# Visualização de Dados

Criar dashboard analítico contendo:

* Gráfico de ocorrência por estação do ano
* Gráfico de temperatura
* Gráfico de umidade
* Distribuição por tipo de solo
* Distribuição por tipo de construção
* Frequência de presas
* Frequência de predadores
* Mapa de calor geográfico

---

# Responsividade

Desktop:

* Sidebar fixa à esquerda
* Conteúdo centralizado

Tablet:

* Sidebar recolhível

Mobile:

* Navegação inferior
* Formulários em uma coluna
* Cartões empilhados
* Campos otimizados para toque

---

# Componentes reutilizáveis

Criar componentes:

* Input
* Select
* MultiSelect
* Checkbox
* Radio Button
* Upload de imagem
* Card estatístico
* Modal
* Tabela
* Stepper
* Mapa
* Gráficos

Utilizar Auto Layout em todos os componentes para garantir responsividade completa.

---

Esse prompt deve gerar algo muito próximo de um MVP real do EcoLox, e não apenas uma digitalização da ficha. Ele preserva toda a estrutura científica do protocolo enquanto transforma a coleta em uma experiência moderna e utilizável em campo.

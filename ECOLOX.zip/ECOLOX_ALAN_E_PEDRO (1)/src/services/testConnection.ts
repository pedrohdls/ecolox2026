// Diagnóstico manual do Supabase: testa credenciais, leitura, escrita, consulta e limpeza.
import { supabase } from "@/supabaseClient";
import { toast } from "sonner";

/**
 * Teste de conexão com Supabase
 * Execute no console do navegador:
 * import { testSupabaseConnection } from "@/services/testConnection";
 * await testSupabaseConnection();
 */

export async function testSupabaseConnection() {
  // Os testes são sequenciais porque cada etapa depende do resultado da anterior.
  console.clear();
  console.log(" TESTE DE CONEXÃO COM SUPABASE\n");
  console.log("=" .repeat(50));

  try {
    // Teste 1: Verificar credenciais
    console.log("\n Teste 1: Verificando credenciais...");
    const url = supabase.supabaseUrl;
    const key = supabase.supabaseKey;

    if (!url || !key) {
      throw new Error(" Credenciais não carregadas! Verifique supabaseClient.js");
    }

    console.log(`   URL: ${url}`);
    console.log(`   Chave: ${key.substring(0, 30)}...`);
    
    if (!key.startsWith("eyJ")) {
      console.warn("    AVISO: A chave deve começar com 'eyJ', não com 'sb_secret_'");
      throw new Error("Chave anônima inválida!");
    }
    console.log("    Credenciais parecem OK\n");

    // Teste 2: Tentar acessar a tabela
    console.log(" Teste 2: Conectando à tabela 'samples'...");
    const { data, error, status } = await supabase
      .from("samples")
      .select("count", { count: "exact", head: true });

    if (error) {
      console.error(" ERRO ao acessar tabela:");
      console.error(`   Mensagem: ${error.message}`);
      console.error(`   Código: ${error.code}`);
      console.error(`   Status: ${status}`);
      throw error;
    }

    console.log(` Tabela acessada com sucesso!`);
    console.log(`   Status HTTP: ${status}`);
    console.log(`   Registros encontrados: ${data}\n`);

    // Teste 3: Criar um registro de teste
    console.log(" Teste 3: Testando inserção de dados...");
    const testRecord = {
      id: `teste-${Date.now()}`,
      date: new Date().toLocaleDateString("pt-BR"),
      time: new Date().toLocaleTimeString("pt-BR"),
      researcher: " Teste Automático",
      incoming_spiders: 99,
      outgoing_spiders: 88,
      balance_spiders: 11,
    };

    console.log(`   Tentando inserir: ${testRecord.id}`);

    const { data: insertedData, error: insertError, status: insertStatus } = await supabase
      .from("samples")
      .insert([testRecord])
      .select();

    if (insertError) {
      console.error(" ERRO ao inserir:");
      console.error(`   Mensagem: ${insertError.message}`);
      console.error(`   Código: ${insertError.code}`);
      console.error(`   Detalhes:`, insertError.details);
      throw insertError;
    }

    console.log(` Inserção bem-sucedida!`);
    console.log(`   Status HTTP: ${insertStatus}`);
    console.log(`   Dados inseridos:`, insertedData, "\n");

    // Teste 4: Consultar o registro inserido
    console.log(" Teste 4: Verificando dados inseridos...");
    const { data: queryData, error: queryError } = await supabase
      .from("samples")
      .select("*")
      .eq("id", testRecord.id);

    if (queryError) {
      console.error(" ERRO ao consultar:", queryError.message);
      throw queryError;
    }

    console.log(` Consulta bem-sucedida!`);
    console.log(`   Registros encontrados: ${queryData?.length || 0}`);
    if (queryData?.length) {
      console.log(`   Primeiro registro:`, queryData[0], "\n");
    }

    // Teste 5: Deletar o registro de teste
    console.log(" Teste 5: Limpando dados de teste...");
    const { error: deleteError, status: deleteStatus } = await supabase
      .from("samples")
      .delete()
      .eq("id", testRecord.id);

    if (deleteError) {
      console.warn(" Aviso ao limpar:", deleteError.message);
    } else {
      console.log(` Limpeza bem-sucedida! (Status: ${deleteStatus})\n`);
    }

    // Resultado final
    console.log("=" .repeat(50));
    console.log(" TODOS OS TESTES PASSARAM!");
    console.log(" Supabase está conectado e funcionando!\n");
    
    toast.success(" Supabase conectado com sucesso!");
    return true;

  } catch (error: any) {
    console.error("\n" + "=" .repeat(50));
    console.error(" TESTE FALHOU!");
    console.error("=" .repeat(50));
    console.error("\nErro completo:", error);
    console.error("\n Possíveis causas:");
    console.error("1. URL incorreta em supabaseClient.js");
    console.error("2. Chave anônima incorreta (deve começar com 'eyJ')");
    console.error("3. Tabela 'samples' não existe no Supabase");
    console.error("4. Políticas de segurança (RLS) não permitem inserção");
    console.error("5. CORS não configurado");
    
    toast.error(" Erro na conexão com Supabase");
    return false;
  }
}

// Teste rápido (executar no console)
export async function quickTest() {
  // Versão curta para verificar apenas se a tabela responde sem criar dados.
  console.log(" Teste rápido - verificando se Supabase responde...\n");
  try {
    const { data, error } = await supabase.from("samples").select("count", { count: "exact", head: true });
    if (error) throw error;
    console.log(" Supabase respondeu! Tudo OK!");
    return true;
  } catch (e) {
    console.error(" Erro:", e);
    return false;
  }
}

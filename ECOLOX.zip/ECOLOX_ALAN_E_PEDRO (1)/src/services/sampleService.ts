// Camada de persistência: traduz o modelo do frontend para as colunas da tabela `samples`.
import { supabase } from "@/supabaseClient";
import type { Sample } from "@/app/App";

function normalizeDateForDatabase(date: string) {
  const brazilianDate = date.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  return brazilianDate
    ? `${brazilianDate[3]}-${brazilianDate[2]}-${brazilianDate[1]}`
    : date;
}

// Criar nova coleta
export async function createSample(sample: Sample) {
  console.log("📤 [createSample] Iniciando salvamento...");
  console.log("📊 Dados a salvar:", sample);
  
  try {
    // Preparar o payload com os nomes snake_case esperados pelo banco.
    const dataToInsert = {
      id: sample.id,
      date: normalizeDateForDatabase(sample.date),
      time: sample.time,
      researcher: sample.researcher,
      incoming_spiders: sample.incomingSpiders,
      outgoing_spiders: sample.outgoingSpiders,
      balance_spiders: sample.balanceSpiders,
      owner_name: sample.ownerName,
      owner_phone: sample.ownerPhone,
      owner_address: sample.ownerAddress,
      owner_city: sample.ownerCity,
      owner_neighborhood: sample.ownerNeighborhood,
      owner_reference: sample.ownerReference,
      latitude: sample.latitude,
      longitude: sample.longitude,
      sunlight: sample.sunlight,
      temperature: sample.temperature,
      humidity: sample.humidity,
      vegetation: sample.vegetation,
      soil_type: sample.soilType,
      climate: sample.climate,
      season: sample.season,
      month: sample.month,
      shed_age: sample.shedAge,
      frequency_of_use: sample.frequencyOfUse,
      architectural_details: sample.architecturalDetails,
      roof_material: sample.roofMaterial,
      wall_material: sample.wallMaterial,
      luminosity: sample.luminosity,
      floor_material: sample.floorMaterial,
      airy_environment: sample.airyEnvironment,
      substrate_material: sample.substrateMaterial,
      closed_area_size: sample.closedAreaSize,
      height: sample.height,
      construction_observations: sample.constructionObservations,
      farm_animals: sample.farmAnimals,
      farm_animal_type: sample.farmAnimalType,
      other_spiders_presence: sample.otherSpidersPresence,
      other_spiders_type: sample.otherSpidersType,
      prey_presence: sample.preyPresence,
      predator_presence: sample.predatorPresence,
      biological_observations: sample.biologicalObservations,
      created_at: new Date().toISOString(),
    };

    console.log("🔌 Enviando para Supabase...");
    const { error, status } = await supabase
      .from("samples")
      .insert([dataToInsert]);

    console.log(`📡 Resposta Supabase - Status: ${status}`);

    if (error) {
      console.error("❌ ERRO ao salvar coleta:");
      console.error("   Mensagem:", error.message);
      console.error("   Código:", error.code);
      console.error("   Detalhes:", error.details);
      console.error("   Hint:", error.hint);
      throw error;
    }

    console.log("✅ Coleta salva com sucesso!");
    return true;
  } catch (error: any) {
    console.error("❌ Erro na criação da amostra:");
    console.error(error);
    throw error;
  }
}

// Buscar todas as coletas
export async function fetchAllSamples(): Promise<Sample[]> {
  try {
    const { data, error } = await supabase
      .from("samples")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Erro ao buscar coletas:", error);
      throw error;
    }

    // Converter o retorno do banco para o modelo camelCase usado pelos componentes.
    return (data || []).map((item: any) => ({
      id: item.id,
      date: item.date,
      time: item.time,
      researcher: item.researcher,
      incomingSpiders: item.incoming_spiders,
      outgoingSpiders: item.outgoing_spiders,
      balanceSpiders: item.balance_spiders,
      ownerName: item.owner_name,
      ownerPhone: item.owner_phone,
      ownerAddress: item.owner_address,
      ownerCity: item.owner_city,
      ownerNeighborhood: item.owner_neighborhood,
      ownerReference: item.owner_reference,
      latitude: item.latitude,
      longitude: item.longitude,
      sunlight: item.sunlight,
      temperature: item.temperature,
      humidity: item.humidity,
      vegetation: item.vegetation,
      soilType: item.soil_type,
      climate: item.climate,
      season: item.season,
      month: item.month,
      shedAge: item.shed_age,
      frequencyOfUse: item.frequency_of_use,
      architecturalDetails: item.architectural_details,
      roofMaterial: item.roof_material,
      wallMaterial: item.wall_material,
      luminosity: item.luminosity,
      floorMaterial: item.floor_material,
      airyEnvironment: item.airy_environment,
      substrateMaterial: item.substrate_material,
      closedAreaSize: item.closed_area_size,
      height: item.height,
      constructionObservations: item.construction_observations,
      farmAnimals: item.farm_animals,
      farmAnimalType: item.farm_animal_type,
      otherSpidersPresence: item.other_spiders_presence,
      otherSpidersType: item.other_spiders_type,
      preyPresence: item.prey_presence,
      predatorPresence: item.predator_presence,
      biologicalObservations: item.biological_observations,
    }));
  } catch (error) {
    console.error("Erro ao buscar amostras:", error);
    return [];
  }
}

// Atualizar coleta existente
export async function updateSample(sample: Sample) {
  try {
    // O filtro pelo ID garante que somente a coleta atualmente editada seja alterada.
    const { data, error } = await supabase
      .from("samples")
      .update({
        date: normalizeDateForDatabase(sample.date),
        time: sample.time,
        researcher: sample.researcher,
        incoming_spiders: sample.incomingSpiders,
        outgoing_spiders: sample.outgoingSpiders,
        balance_spiders: sample.balanceSpiders,
        owner_name: sample.ownerName,
        owner_phone: sample.ownerPhone,
        owner_address: sample.ownerAddress,
        owner_city: sample.ownerCity,
        owner_neighborhood: sample.ownerNeighborhood,
        owner_reference: sample.ownerReference,
        latitude: sample.latitude,
        longitude: sample.longitude,
        sunlight: sample.sunlight,
        temperature: sample.temperature,
        humidity: sample.humidity,
        vegetation: sample.vegetation,
        soil_type: sample.soilType,
        climate: sample.climate,
        season: sample.season,
        month: sample.month,
        shed_age: sample.shedAge,
        frequency_of_use: sample.frequencyOfUse,
        architectural_details: sample.architecturalDetails,
        roof_material: sample.roofMaterial,
        wall_material: sample.wallMaterial,
        luminosity: sample.luminosity,
        floor_material: sample.floorMaterial,
        airy_environment: sample.airyEnvironment,
        substrate_material: sample.substrateMaterial,
        closed_area_size: sample.closedAreaSize,
        height: sample.height,
        construction_observations: sample.constructionObservations,
        farm_animals: sample.farmAnimals,
        farm_animal_type: sample.farmAnimalType,
        other_spiders_presence: sample.otherSpidersPresence,
        other_spiders_type: sample.otherSpidersType,
        prey_presence: sample.preyPresence,
        predator_presence: sample.predatorPresence,
        biological_observations: sample.biologicalObservations,
      })
      .eq("id", sample.id)
      .select();

    if (error) {
      console.error("Erro ao atualizar coleta:", error);
      throw error;
    }

    console.log("Coleta atualizada com sucesso:", data);
    return data;
  } catch (error) {
    console.error("Erro na atualização da amostra:", error);
    throw error;
  }
}

// Deletar coleta
export async function deleteSample(sampleId: string) {
  try {
    // A exclusão também usa o ID para evitar remover outras coletas.
    const { error } = await supabase
      .from("samples")
      .delete()
      .eq("id", sampleId);

    if (error) {
      console.error("Erro ao deletar coleta:", error);
      throw error;
    }

    console.log("Coleta deletada com sucesso");
  } catch (error) {
    console.error("Erro na exclusão da amostra:", error);
    throw error;
  }
}
